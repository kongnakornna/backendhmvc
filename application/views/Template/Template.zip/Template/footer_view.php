	<div class="clear"></div>
	<div id="footer" class="grid_16">
		<p>Footer <?=$this->lang->line('titleweb');?></p>
	</div>
</div>
