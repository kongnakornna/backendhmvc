<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dev extends MX_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->config->item('Template');
	}
	public function index(){
	     // echo '<pre> Template=>'; print_r('Template'); echo '</pre>';  //Die();
		  $datars = array(
			 "title" => 'Demo',
             "Data"=> 'Data',
             "content_view" => 'Na',
			); 
		  $data = array(
			 "title" => 'Demo',
             "Data"=> $datars,
             "content_view" => 'demo',
			); 
          //echo '<pre>'; print_r($data); echo '</pre>';  Die();
		$this->load->view('Template/Template',$data);
	}
}
