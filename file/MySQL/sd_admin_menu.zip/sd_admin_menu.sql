/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50620
Source Host           : localhost:3306
Source Database       : democi_db

Target Server Type    : MYSQL
Target Server Version : 50620
File Encoding         : 65001

Date: 2017-08-15 10:57:31
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `sd_admin_menu`
-- ----------------------------
DROP TABLE IF EXISTS `sd_admin_menu`;
CREATE TABLE `sd_admin_menu` (
  `admin_menu_id` int(10) NOT NULL AUTO_INCREMENT,
  `admin_menu_id2` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `parent` int(10) NOT NULL DEFAULT '0',
  `admin_menu_alt` varchar(255) DEFAULT NULL,
  `option` varchar(255) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT NULL,
  `create_by` int(10) DEFAULT NULL,
  `lastupdate_date` timestamp NULL DEFAULT NULL,
  `lastupdate_by` int(10) DEFAULT NULL,
  `order_by` tinyint(3) NOT NULL DEFAULT '0',
  `icon` varchar(255) DEFAULT NULL,
  `params` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `lang` char(2) NOT NULL DEFAULT 'en',
  PRIMARY KEY (`admin_menu_id`),
  UNIQUE KEY `uniq` (`admin_menu_id`,`admin_menu_id2`,`parent`,`lang`),
  KEY `index` (`admin_menu_id`,`admin_menu_id2`,`parent`,`order_by`,`status`,`lang`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sd_admin_menu
-- ----------------------------
INSERT INTO `sd_admin_menu` VALUES ('1', '1', 'Overview', '/overview', '0', null, null, '2014-09-04 12:23:37', '1', '2015-09-21 14:34:14', '1', '1', 'fa fa-desktop', null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('2', '2', 'Basic Data', '/basic', '0', null, '1', '2014-09-04 12:23:37', '1', '2015-09-05 17:20:51', '1', '2', 'fa fa-cog', null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('4', '4', 'Email Setting', '/emailsetting', '27', null, null, '2014-09-04 12:23:37', '1', '2015-04-30 01:31:21', '1', '11', 'fa fa-pencil-square-o', null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('6', '6', 'Seting Work Time', '/setingworktime', '2', null, null, '2014-09-04 12:23:37', '1', '2015-09-05 19:23:04', '1', '8', 'fa fa-paperclip', null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('7', '7', 'Upload File', '/uploadfile', '2', null, null, '2014-09-04 12:23:37', '1', null, null, '1', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('10', '10', 'Sub Category', '/subcategory', '9', null, null, '2014-09-04 12:23:37', '1', null, null, '0', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('11', '11', 'Type', '/dara_type', '2', null, null, '2014-09-04 12:23:37', '1', null, null, '2', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('12', '12', 'Tags', '/tags', '2', null, '', '2014-09-04 12:23:37', '1', null, null, '8', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('13', '13', 'Emergency', '/emergency', '2', null, null, '2014-09-04 12:23:37', '1', null, null, '10', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('14', '1', 'ภาพรวม', '/overview', '0', null, null, '2014-09-04 12:23:37', '1', '2015-09-21 14:34:14', '1', '1', 'fa fa-desktop ', null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('15', '2', 'ข้อมูลพื้นฐาน', '/basic', '0', null, '1', '2014-09-04 12:23:37', '1', '2015-09-05 17:20:51', '1', '2', 'fa fa-cog', null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('17', '4', 'Email Setting', '/emailsetting', '27', null, null, '2014-09-04 12:23:37', '1', '2015-04-30 01:31:21', '1', '11', 'fa fa-pencil-square-o', null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('19', '6', 'ตั้งต่าเวลาทำงาน', '/setingworktime', '2', null, null, '2014-09-04 12:23:37', '1', '2015-09-05 19:23:04', '1', '8', 'fa fa-paperclip', null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('20', '7', 'อัปโหลดไฟล์', '/uploadfile', '15', null, null, '2014-09-04 12:23:37', '1', null, null, '1', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('23', '10', 'หมวดย่อย', '/subcategory', '22', null, null, '2014-09-04 12:23:37', '1', null, null, '0', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('24', '11', 'ประเภท', '/dara_type', '15', null, null, '2014-09-04 12:23:37', '1', null, null, '2', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('25', '12', 'Tags', '/tags', '15', null, '', '2014-09-04 12:23:37', '1', null, null, '8', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('26', '13', 'ลบฉุกเฉิน', '/emergency', '15', null, null, '2014-09-04 12:23:37', '1', null, null, '10', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('33', '33', 'JSON', '/json', '28', null, null, '2014-09-15 10:23:30', '1', null, null, '1', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('34', '33', 'JSON', '/json', '30', null, null, '2014-09-15 10:23:30', '1', null, null, '1', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('35', '35', 'Navigation', '/json/nav', '28', null, null, '2014-09-15 10:23:30', '1', null, null, '0', null, null, '0', 'en');
INSERT INTO `sd_admin_menu` VALUES ('36', '35', 'เมนู', '/json/nav', '30', null, null, '2014-09-15 10:23:30', '1', null, null, '0', null, null, '0', 'th');
INSERT INTO `sd_admin_menu` VALUES ('37', '37', 'Errorlog', '/errorlog', '2', null, null, '2014-10-22 15:07:14', '1', null, null, '5', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('38', '37', 'Errorlog', '/errorlog', '15', null, null, '2014-10-22 15:07:14', '1', null, null, '5', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('39', '39', 'Credit By', '/credit', '2', null, null, '2014-10-22 15:30:15', '1', null, null, '7', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('40', '39', 'ภาพจาก', '/credit', '15', null, null, '2014-10-22 15:30:15', '1', null, null, '7', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('41', '41', 'Report', '/report', '0', null, '1', '2014-10-27 16:57:12', '1', '2015-09-21 14:34:37', '1', '6', 'fa fa-bar-chart-o ', null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('42', '41', 'รายงาน', '/report', '0', null, '1', '2014-10-27 16:57:12', '1', '2015-09-21 14:34:37', '1', '6', 'fa fa-bar-chart-o ', null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('51', '51', 'Admin menu', '/admin_menu', '27', null, null, '2014-10-31 14:05:07', '1', null, null, '3', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('52', '51', 'เมนูแอดมิน', '/admin_menu', '27', null, null, '2014-10-31 14:05:07', '1', null, null, '3', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('55', '55', 'Delete', '/admin_delete', '27', null, null, '2014-11-07 14:56:43', '1', '2014-11-18 16:09:50', '3', '5', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('56', '55', 'ลบข้อมูล จริง', '/admin_delete', '27', null, null, '2014-11-07 14:56:43', '1', '2014-11-18 16:09:50', '3', '5', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('59', '59', 'Activity Logs', '/activity_logsna', '27', null, null, '2014-11-12 14:55:22', '3', '2015-09-05 21:23:01', '1', '6', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('60', '59', 'บันทึกการทำงาน', '/activity_logsna', '27', null, null, '2014-11-12 14:55:22', '3', '2015-09-05 21:23:01', '1', '6', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('61', '61', 'Admin Group', '/team', '27', null, null, '2014-11-18 12:56:13', '3', '2014-11-25 14:08:20', '1', '4', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('62', '61', 'แอดมินกรุ๊ป', '/team', '27', null, null, '2014-11-18 12:56:13', '3', '2014-11-25 14:08:20', '1', '4', null, null, '1', 'th');
INSERT INTO `sd_admin_menu` VALUES ('63', '63', 'User Event Report', '/userlogs', '41', null, null, '2014-12-02 15:39:39', '1', '2015-08-22 18:33:47', '1', '4', null, null, '1', 'en');
INSERT INTO `sd_admin_menu` VALUES ('64', '63', 'User Event Report', '/userlogs', '41', null, null, '2014-12-02 15:39:39', '1', '2015-08-22 18:33:47', '1', '4', null, null, '1', 'th');
