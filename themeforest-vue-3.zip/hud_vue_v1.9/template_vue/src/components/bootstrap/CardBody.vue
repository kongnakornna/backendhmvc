<template>
	<div class="card-body">
		<slot />
	</div>
</template>
