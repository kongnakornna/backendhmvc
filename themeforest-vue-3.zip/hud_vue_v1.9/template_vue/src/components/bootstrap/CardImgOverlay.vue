<template>
	<div class="card-img-overlay">
		<slot />
	</div>
</template>
