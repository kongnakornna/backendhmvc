<template>
	<div class="card-group">
		<slot />
	</div>
</template>
