<script>
import VueTagsInput from "@sipec/vue3-tags-input";

export default {
  components: {
    VueTagsInput
  },
};
</script>

<template>
	<vue-tags-input />
</template>