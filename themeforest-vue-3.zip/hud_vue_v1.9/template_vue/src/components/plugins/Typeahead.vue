<script>
import Vue3SimpleTypeahead from 'vue3-simple-typeahead';
import 'vue3-simple-typeahead/dist/vue3-simple-typeahead.css';

export default {
	name: 'typeahead',
	components: {
		Vue3SimpleTypeahead
	}
}
</script>
<template>
	<vue3-simple-typeahead></vue3-simple-typeahead>
</template>